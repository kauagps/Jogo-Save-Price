x1 - 1 tile 16x16 , spasing 1 
x2 - 1 tile 32x32 , spasing 2
x5 - 1 tile 80x80 , spasing 5
x10 - 1 tile 160x160 , spasing 10
Credit me as Azat Yantimirov (or ZigWin)